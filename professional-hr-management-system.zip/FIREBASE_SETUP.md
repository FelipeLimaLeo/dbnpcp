# 🔥 Configuração do Firebase - DBN RH

## Passo a Passo para Configurar

### 1️⃣ Criar Projeto no Firebase

1. Acesse [Firebase Console](https://console.firebase.google.com/)
2. Clique em **"Adicionar projeto"** ou **"Create a project"**
3. Digite o nome do projeto: `dbn-rh` (ou outro de sua preferência)
4. Clique em **Continuar**
5. Desative o Google Analytics (opcional)
6. Clique em **Criar projeto**

---

### 2️⃣ Configurar Firestore Database

1. No menu lateral, clique em **Build** → **Firestore Database**
2. Clique em **Criar banco de dados**
3. Escolha o modo de segurança:
   - **Modo de teste**: Permite leitura/escrita por 30 dias (bom para desenvolvimento)
   - **Modo de produção**: Mais seguro, requer regras personalizadas
4. Selecione a localização (recomendado: `southamerica-east1` - São Paulo)
5. Clique em **Ativar**

---

### 3️⃣ Registrar Aplicação Web

1. No Firebase Console, clique no ícone de **Web** (</>) ao lado de "Visão geral do projeto"
2. Digite o nickname do app: `DBN RH Web`
3. **Não** marque a opção de Firebase Hosting
4. Clique em **Registrar app**

---

### 4️⃣ Copiar Configurações

Você verá um código como este:

```javascript
const firebaseConfig = {
  apiKey: "AIzaSyXXXXXXXXXXXXXXXXXXXXXXXXXX",
  authDomain: "dbn-rh.firebaseapp.com",
  projectId: "dbn-rh",
  storageBucket: "dbn-rh.appspot.com",
  messagingSenderId: "123456789012",
  appId: "1:123456789012:web:abcdef123456"
};
```

---

### 5️⃣ Atualizar Arquivo de Configuração

1. Abra o arquivo `src/firebase/config.ts` no seu projeto
2. Substitua os valores pelos do seu projeto:

```typescript
const firebaseConfig = {
  apiKey: "SUA_API_KEY_AQUI",
  authDomain: "SEU_PROJETO.firebaseapp.com",
  projectId: "SEU_PROJECT_ID",
  storageBucket: "SEU_PROJETO.appspot.com",
  messagingSenderId: "SEU_MESSAGING_SENDER_ID",
  appId: "SEU_APP_ID"
};
```

3. Salve o arquivo

---

### 6️⃣ Configurar Regras de Segurança (Opcional mas Recomendado)

No Firebase Console, vá em **Firestore Database** → **Regras**:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Permite leitura e escrita para desenvolvimento
    match /{document=**} {
      allow read, write: if true;
    }
  }
}
```

**⚠️ IMPORTANTE**: Para produção, configure autenticação e regras mais restritivas!

---

### 7️⃣ Testar a Conexão

1. Execute o projeto: `npm run dev`
2. Tente cadastrar um funcionário
3. Verifique no Firebase Console → Firestore Database se os dados apareceram

---

## 📊 Estrutura do Banco de Dados

### Coleção: `employees`
```
employees/
  ├── {id_funcionario_1}/
  │   ├── nomeCompleto: "Maria Silva"
  │   ├── cpf: "123.456.789-00"
  │   ├── dataNascimento: "1990-03-15"
  │   ├── dataAdmissao: "2020-01-10"
  │   ├── isPCD: false
  │   ├── email: "maria@dbn.com.br"
  │   ├── telefone: "(11) 98765-4321"
  │   ├── cargo: "Analista de RH"
  │   ├── departamento: "Recursos Humanos"
  │   ├── dataFeriasInicio: "2026-02-01"
  │   ├── dataFeriasFim: "2026-02-30"
  │   ├── ativo: true
  │   ├── createdAt: Timestamp
  │   └── updatedAt: Timestamp
  └── {id_funcionario_2}/
      └── ...
```

### Coleção: `notifications`
```
notifications/
  ├── {id_notificacao_1}/
  │   ├── type: "aniversario" | "ferias"
  │   ├── message: "Aniversário de Maria Silva em 15/03/2026"
  │   ├── employeeName: "Maria Silva"
  │   ├── employeeId: "{id_funcionario}"
  │   ├── date: "2026-03-15"
  │   ├── daysUntil: 45
  │   ├── read: false
  │   └── createdAt: Timestamp
  └── {id_notificacao_2}/
      └── ...
```

---

## 🔄 Como Funciona

1. **Tempo Real**: O sistema usa `onSnapshot` do Firebase para atualizar automaticamente quando há mudanças
2. **Sincronização**: Dados sincronizados em todos os dispositivos conectados
3. **Persistência**: Dados salvos na nuvem do Google
4. **Offline**: Firebase tem cache offline automático

---

## 🛡️ Segurança para Produção

Para produção, configure **Autenticação** e atualize as regras:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Apenas usuários autenticados podem acessar
    match /{document=**} {
      allow read, write: if request.auth != null;
    }
  }
}
```

---

## 📱 Vantagens do Firebase

✅ **Gratuito** até 1GB de armazenamento e 50K leituras/dia  
✅ **Tempo real** - dados sincronizados instantaneamente  
✅ **Escalável** - cresce com sua empresa  
✅ **Seguro** - infraestrutura do Google  
✅ **Backup automático** - seus dados estão protegidos  

---

## 🆘 Problemas Comuns

### Erro: "Firebase: No Firebase App '[DEFAULT]' has been created"
- Verifique se preencheu corretamente o arquivo `config.ts`

### Erro: "Missing or insufficient permissions"
- Configure as regras do Firestore como mostrado acima

### Dados não aparecem
- Verifique se o projeto está selecionado corretamente no Firebase Console
- Confira se o Firestore está ativado

---

## 📞 Suporte

Documentação oficial: https://firebase.google.com/docs/firestore

---

**Pronto! Seu sistema de RH agora tem um banco de dados profissional na nuvem! 🎉**
