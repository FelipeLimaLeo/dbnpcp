# 🧡 DBN RH - Sistema de Gestão de Funcionários

Sistema profissional de Recursos Humanos com design na paleta laranja e branco, desenvolvido com React, Vite, Tailwind CSS e Firebase.

---

## ✨ Funcionalidades

### 📋 Gestão de Funcionários
- Cadastro completo com:
  - Nome completo
  - CPF (com formatação automática)
  - Data de nascimento
  - Data de admissão
  - Flag PCD (Pessoa com Deficiência)
  - Email e telefone
  - Cargo e departamento
  - Período de férias
  - Status (ativo/inativo)

### 🔔 Sistema de Alertas Inteligente
- **Notificações com 45 dias de antecedência** para:
  - 🎂 Aniversários dos funcionários
  - 🏖️ Período de férias
- Alertas visuais no dashboard
- Notificações por email (simulado)
- Marcar como lido individual ou em lote

### 📊 Dashboard Profissional
- Métricas em tempo real
- Cards com estatísticas
- Alertas recentes
- Acesso rápido às funcionalidades

### 🔍 Busca Avançada
- Filtrar por nome, CPF, cargo ou departamento
- Resultados em tempo real

### 💾 Banco de Dados na Nuvem
- Firebase Firestore
- Sincronização em tempo real
- Dados persistentes
- Acesso multi-dispositivo

---

## 🚀 Tecnologias Utilizadas

- **React 18** - Framework UI
- **Vite** - Build tool ultra-rápido
- **Tailwind CSS** - Estilização moderna
- **TypeScript** - Tipagem estática
- **Firebase** - Banco de dados e backend
- **Lucide React** - Ícones modernos

---

## 📦 Instalação

### 1. Instalar dependências
```bash
npm install
```

### 2. Configurar Firebase
Siga as instruções no arquivo `FIREBASE_SETUP.md`

### 3. Rodar em desenvolvimento
```bash
npm run dev
```

### 4. Build para produção
```bash
npm run build
```

---

## 🎨 Design System

### Cores
- **Laranja Primário**: `#ea580c` (orange-600)
- **Laranja Secundário**: `#f97316` (orange-500)
- **Branco**: `#ffffff`
- **Cinza Fundo**: `#f9fafb` (gray-50)

### Tipografia
- Fontes do sistema (sans-serif)
- Hierarquia clara de títulos

### Componentes
- Cards com sombras suaves
- Bordas arredondadas (rounded-xl)
- Transições suaves
- Design responsivo

---

## 📁 Estrutura do Projeto

```
dbn-rh/
├── src/
│   ├── firebase/
│   │   ├── config.ts       # Configuração do Firebase
│   │   └── services.ts     # Serviços do banco de dados
│   ├── App.tsx             # Componente principal
│   ├── main.tsx            # Entry point
│   └── index.css           # Estilos globais
├── public/                 # Arquivos estáticos
├── index.html              # HTML principal
├── FIREBASE_SETUP.md       # Guia de configuração Firebase
└── README.md               # Este arquivo
```

---

## 🔐 Segurança

### Desenvolvimento
- Modo de teste do Firebase ativado
- Acesso livre para desenvolvimento

### Produção
- Configurar autenticação de usuários
- Atualizar regras de segurança do Firestore
- Implementar controle de acesso por função

---

## 📊 Limites do Plano Gratuito (Firebase)

- **Armazenamento**: 1 GB
- **Leituras/dia**: 50.000
- **Gravações/dia**: 20.000
- **Exclusões/dia**: 20.000

*Suficiente para pequenas e médias empresas!*

---

## 🛠️ Comandos Disponíveis

```bash
# Desenvolvimento
npm run dev          # Inicia servidor de desenvolvimento

# Produção
npm run build        # Gera build otimizado
npm run preview      # Preview do build

# Utilitários
npm run lint         # Verifica código
```

---

## 📱 Responsividade

O sistema é totalmente responsivo e funciona em:
- 🖥️ Desktop (1920px+)
- 💻 Laptop (1024px - 1919px)
- 📱 Tablet (768px - 1023px)
- 📱 Mobile (320px - 767px)

---

## 🎯 Próximas Melhorias (Sugestões)

- [ ] Autenticação de usuários (login/senha)
- [ ] Exportação de relatórios em PDF
- [ ] Integração com email real (SendGrid, AWS SES)
- [ ] Upload de documentos (foto, currículo)
- [ ] Histórico de alterações
- [ ] Dashboard de aniversariantes do mês
- [ ] Controle de ponto
- [ ] Avaliação de desempenho

---

## 📞 Suporte

Para dúvidas sobre configuração do Firebase, consulte `FIREBASE_SETUP.md`.

---

## 📄 Licença

Este projeto é de uso interno da DBN.

---

**Desenvolvido com ❤️ para DBN RH**
