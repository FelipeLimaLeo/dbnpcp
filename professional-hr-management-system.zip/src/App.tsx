import React, { useState, useEffect, useMemo } from 'react';
import { 
  Users, 
  Calendar, 
  Bell, 
  Plus, 
  Search, 
  Edit, 
  Trash2, 
  X, 
  Check, 
  AlertCircle,
  Home,
  Settings,
  Menu,
  ChevronRight,
  TrendingUp,
  Clock,
  Award,
  Mail
} from 'lucide-react';
import { 
  Employee as FirebaseEmployee, 
  createEmployee,
  updateEmployee,
  deleteEmployee,
  markNotificationAsRead,
  markAllNotificationsAsRead,
  subscribeToEmployees,
  subscribeToNotifications
} from './firebase/services';

// Types
interface Employee {
  id: string;
  nomeCompleto: string;
  cpf: string;
  dataNascimento: string;
  dataAdmissao: string;
  isPCD: boolean;
  email: string;
  telefone: string;
  cargo: string;
  departamento: string;
  dataFeriasInicio: string;
  dataFeriasFim: string;
  ativo: boolean;
}

interface Notification {
  id: string;
  type: 'aniversario' | 'ferias' | 'geral';
  message: string;
  employeeName: string;
  date: string;
  daysUntil: number;
  read: boolean;
}

// Utility functions
const formatDate = (dateString: string): string => {
  if (!dateString) return '';
  const date = new Date(dateString);
  return date.toLocaleDateString('pt-BR');
};

const formatCPF = (cpf: string): string => {
  const cleaned = cpf.replace(/\D/g, '');
  return cleaned
    .replace(/(\d{3})(\d)/, '$1.$2')
    .replace(/(\d{3})(\d)/, '$1.$2')
    .replace(/(\d{3})(\d{1,2})/, '$1-$2')
    .replace(/(-\d{2})\d+?$/, '$1');
};

const calculateDaysUntil = (targetDate: string): number => {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const target = new Date(targetDate);
  target.setHours(0, 0, 0, 0);
  const diffTime = target.getTime() - today.getTime();
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
};

const calculateNextOccurrence = (dateString: string, type: 'birthday' | 'vacation'): Date => {
  const date = new Date(dateString);
  const today = new Date();
  
  if (type === 'birthday') {
    const nextBirthday = new Date(today.getFullYear(), date.getMonth(), date.getDate());
    if (nextBirthday < today) {
      nextBirthday.setFullYear(today.getFullYear() + 1);
    }
    return nextBirthday;
  } else {
    // For vacation, use the start date from current year or next
    const vacationDate = new Date(dateString);
    if (vacationDate < today) {
      vacationDate.setFullYear(today.getFullYear() + 1);
    }
    return vacationDate;
  }
};

// Main App Component
export default function App() {
  // State
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [currentView, setCurrentView] = useState<'dashboard' | 'employees' | 'notifications' | 'settings'>('dashboard');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [showNotifications, setShowNotifications] = useState(false);

  // Form state
  const [formData, setFormData] = useState<Partial<Employee>>({
    nomeCompleto: '',
    cpf: '',
    dataNascimento: '',
    dataAdmissao: '',
    isPCD: false,
    email: '',
    telefone: '',
    cargo: '',
    departamento: '',
    dataFeriasInicio: '',
    dataFeriasFim: '',
    ativo: true
  });

  // Load data from Firebase with real-time subscription
  useEffect(() => {
    // Subscribe to employees
    const unsubscribeEmployees = subscribeToEmployees((employeesData) => {
      setEmployees(employeesData as Employee[]);
    });

    // Subscribe to notifications
    const unsubscribeNotifications = subscribeToNotifications((notificationsData) => {
      setNotifications(notificationsData as Notification[]);
    });

    return () => {
      unsubscribeEmployees();
      unsubscribeNotifications();
    };
  }, []);

  // Generate notifications
  useEffect(() => {
    const newNotifications: Notification[] = [];

    employees.forEach(employee => {
      // Check birthday (45 days before)
      if (employee.dataNascimento) {
        const nextBirthday = calculateNextOccurrence(employee.dataNascimento, 'birthday');
        const daysUntilBirthday = calculateDaysUntil(nextBirthday.toISOString());
        
        if (daysUntilBirthday <= 45 && daysUntilBirthday >= 0) {
          newNotifications.push({
            id: `bday-${employee.id}-${nextBirthday.getFullYear()}`,
            type: 'aniversario',
            message: `Aniversário de ${employee.nomeCompleto} em ${formatDate(nextBirthday.toISOString())}`,
            employeeName: employee.nomeCompleto,
            date: nextBirthday.toISOString(),
            daysUntil: daysUntilBirthday,
            read: false
          });
        }
      }

      // Check vacation (45 days before)
      if (employee.dataFeriasInicio) {
        const nextVacation = calculateNextOccurrence(employee.dataFeriasInicio, 'vacation');
        const daysUntilVacation = calculateDaysUntil(nextVacation.toISOString());
        
        if (daysUntilVacation <= 45 && daysUntilVacation >= 0) {
          newNotifications.push({
            id: `vac-${employee.id}-${nextVacation.getFullYear()}`,
            type: 'ferias',
            message: `Férias de ${employee.nomeCompleto} iniciam em ${formatDate(nextVacation.toISOString())}`,
            employeeName: employee.nomeCompleto,
            date: nextVacation.toISOString(),
            daysUntil: daysUntilVacation,
            read: false
          });
        }
      }
    });

    // Merge with existing notifications, keeping unread ones
    setNotifications(prev => {
      const existingIds = new Set(newNotifications.map(n => n.id));
      const unreadExisting = prev.filter(n => !n.read && !existingIds.has(n.id));
      return [...newNotifications, ...unreadExisting];
    });
  }, [employees]);

  // Filter employees
  const filteredEmployees = useMemo(() => {
    return employees.filter(emp => {
      const searchLower = searchTerm.toLowerCase();
      return (
        emp.nomeCompleto.toLowerCase().includes(searchLower) ||
        emp.cpf.includes(searchLower) ||
        emp.cargo.toLowerCase().includes(searchLower) ||
        emp.departamento.toLowerCase().includes(searchLower)
      );
    });
  }, [employees, searchTerm]);

  // Statistics
  const stats = useMemo(() => {
    const totalEmployees = employees.filter(e => e.ativo).length;
    const pcdEmployees = employees.filter(e => e.ativo && e.isPCD).length;
    const upcomingBirthdays = notifications.filter(n => n.type === 'aniversario' && !n.read).length;
    const upcomingVacations = notifications.filter(n => n.type === 'ferias' && !n.read).length;
    
    return { totalEmployees, pcdEmployees, upcomingBirthdays, upcomingVacations };
  }, [employees, notifications]);

  // Handlers
  const handleOpenModal = (employee?: Employee) => {
    if (employee) {
      setEditingEmployee(employee);
      setFormData(employee);
    } else {
      setEditingEmployee(null);
      setFormData({
        nomeCompleto: '',
        cpf: '',
        dataNascimento: '',
        dataAdmissao: '',
        isPCD: false,
        email: '',
        telefone: '',
        cargo: '',
        departamento: '',
        dataFeriasInicio: '',
        dataFeriasFim: '',
        ativo: true
      });
    }
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingEmployee(null);
    setFormData({
      nomeCompleto: '',
      cpf: '',
      dataNascimento: '',
      dataAdmissao: '',
      isPCD: false,
      email: '',
      telefone: '',
      cargo: '',
      departamento: '',
      dataFeriasInicio: '',
      dataFeriasFim: '',
      ativo: true
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validação dos campos obrigatórios
    if (!formData.nomeCompleto?.trim()) {
      alert('Por favor, preencha o nome completo.');
      return;
    }
    if (!formData.cpf?.trim()) {
      alert('Por favor, preencha o CPF.');
      return;
    }
    if (!formData.email?.trim()) {
      alert('Por favor, preencha o email.');
      return;
    }
    if (!formData.dataNascimento) {
      alert('Por favor, preencha a data de nascimento.');
      return;
    }
    if (!formData.dataAdmissao) {
      alert('Por favor, preencha a data de admissão.');
      return;
    }
    if (!formData.cargo?.trim()) {
      alert('Por favor, preencha o cargo.');
      return;
    }
    if (!formData.departamento?.trim()) {
      alert('Por favor, preencha o departamento.');
      return;
    }
    
    try {
      if (editingEmployee) {
        // Atualizar funcionário no Firebase
        await updateEmployee(editingEmployee.id, formData as FirebaseEmployee);
        alert('Funcionário atualizado com sucesso!');
      } else {
        // Criar novo funcionário no Firebase
        await createEmployee(formData as FirebaseEmployee);
        alert('Funcionário cadastrado com sucesso!');
      }
      
      handleCloseModal();
    } catch (error) {
      alert('Erro ao salvar funcionário. Verifique sua conexão com o Firebase.');
      console.error('Erro no cadastro:', error);
    }
  };

  const handleDelete = async (id: string) => {
    if (confirm('Tem certeza que deseja excluir este funcionário?')) {
      try {
        await deleteEmployee(id);
        alert('Funcionário excluído com sucesso!');
      } catch (error) {
        alert('Erro ao excluir funcionário. Tente novamente.');
        console.error('Erro na exclusão:', error);
      }
    }
  };

  const handleMarkAsRead = async (notificationId: string) => {
    try {
      await markNotificationAsRead(notificationId);
    } catch (error) {
      console.error('Erro ao marcar notificação como lida:', error);
    }
  };

  const handleMarkAllAsRead = async () => {
    try {
      await markAllNotificationsAsRead();
    } catch (error) {
      console.error('Erro ao marcar todas notificações como lidas:', error);
    }
  };

  const unreadNotifications = notifications.filter(n => !n.read);

  // Render functions
  const renderDashboard = () => (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-orange-100 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500 font-medium">Total de Funcionários</p>
              <p className="text-3xl font-bold text-gray-800 mt-2">{stats.totalEmployees}</p>
            </div>
            <div className="bg-orange-100 p-3 rounded-lg">
              <Users className="w-6 h-6 text-orange-600" />
            </div>
          </div>
          <div className="mt-4 flex items-center text-sm">
            <TrendingUp className="w-4 h-4 text-green-500 mr-1" />
            <span className="text-green-500 font-medium">Ativos</span>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-orange-100 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500 font-medium">Funcionários PCD</p>
              <p className="text-3xl font-bold text-gray-800 mt-2">{stats.pcdEmployees}</p>
            </div>
            <div className="bg-orange-100 p-3 rounded-lg">
              <Award className="w-6 h-6 text-orange-600" />
            </div>
          </div>
          <div className="mt-4 flex items-center text-sm">
            <span className="text-gray-500">Inclusão e diversidade</span>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-orange-100 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500 font-medium">Aniversários (45 dias)</p>
              <p className="text-3xl font-bold text-gray-800 mt-2">{stats.upcomingBirthdays}</p>
            </div>
            <div className="bg-orange-100 p-3 rounded-lg">
              <Calendar className="w-6 h-6 text-orange-600" />
            </div>
          </div>
          <div className="mt-4 flex items-center text-sm">
            <AlertCircle className="w-4 h-4 text-orange-500 mr-1" />
            <span className="text-orange-500 font-medium">Próximos</span>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-orange-100 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500 font-medium">Férias (45 dias)</p>
              <p className="text-3xl font-bold text-gray-800 mt-2">{stats.upcomingVacations}</p>
            </div>
            <div className="bg-orange-100 p-3 rounded-lg">
              <Clock className="w-6 h-6 text-orange-600" />
            </div>
          </div>
          <div className="mt-4 flex items-center text-sm">
            <AlertCircle className="w-4 h-4 text-orange-500 mr-1" />
            <span className="text-orange-500 font-medium">Próximas</span>
          </div>
        </div>
      </div>

      {/* Recent Notifications */}
      <div className="bg-white rounded-xl shadow-sm border border-orange-100 p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-semibold text-gray-800 flex items-center">
            <Bell className="w-5 h-5 mr-2 text-orange-600" />
            Alertas Recentes
          </h2>
          <button 
            onClick={() => setCurrentView('notifications')}
            className="text-orange-600 hover:text-orange-700 text-sm font-medium flex items-center"
          >
            Ver todos <ChevronRight className="w-4 h-4 ml-1" />
          </button>
        </div>
        
        {unreadNotifications.length === 0 ? (
          <div className="text-center py-8">
            <Bell className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500">Nenhum alerta pendente</p>
          </div>
        ) : (
          <div className="space-y-3">
            {unreadNotifications.slice(0, 5).map(notification => (
              <div 
                key={notification.id}
                className={`flex items-center justify-between p-4 rounded-lg border-l-4 ${
                  notification.type === 'aniversario' 
                    ? 'bg-orange-50 border-orange-500' 
                    : 'bg-blue-50 border-blue-500'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <div className={`p-2 rounded-full ${
                    notification.type === 'aniversario' 
                      ? 'bg-orange-200' 
                      : 'bg-blue-200'
                  }`}>
                    {notification.type === 'aniversario' ? (
                      <Calendar className="w-5 h-5 text-orange-600" />
                    ) : (
                      <Clock className="w-5 h-5 text-blue-600" />
                    )}
                  </div>
                  <div>
                    <p className="font-medium text-gray-800">{notification.message}</p>
                    <p className="text-sm text-gray-500">
                      {notification.daysUntil === 0 
                        ? 'Hoje' 
                        : notification.daysUntil === 1 
                          ? 'Amanhã' 
                          : `Em ${notification.daysUntil} dias`
                      }
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => handleMarkAsRead(notification.id)}
                  className="p-2 hover:bg-white/50 rounded-full transition-colors"
                >
                  <Check className="w-5 h-5 text-gray-400 hover:text-green-500" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl shadow-lg p-6 text-white">
          <h3 className="text-lg font-semibold mb-2">Cadastrar Novo Funcionário</h3>
          <p className="text-orange-100 mb-4">Adicione um novo colaborador ao sistema de RH</p>
          <button
            onClick={() => handleOpenModal()}
            className="bg-white text-orange-600 px-6 py-2 rounded-lg font-medium hover:bg-orange-50 transition-colors flex items-center"
          >
            <Plus className="w-5 h-5 mr-2" />
            Novo Cadastro
          </button>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-orange-100 p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-2">Acesso Rápido</h3>
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => setCurrentView('employees')}
              className="flex items-center space-x-2 p-3 rounded-lg hover:bg-orange-50 transition-colors text-left"
            >
              <Users className="w-5 h-5 text-orange-600" />
              <span className="text-sm font-medium text-gray-700">Funcionários</span>
            </button>
            <button
              onClick={() => setCurrentView('notifications')}
              className="flex items-center space-x-2 p-3 rounded-lg hover:bg-orange-50 transition-colors text-left"
            >
              <Bell className="w-5 h-5 text-orange-600" />
              <span className="text-sm font-medium text-gray-700">Alertas</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  const renderEmployees = () => (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">Funcionários</h2>
          <p className="text-gray-500">Gerencie os colaboradores da empresa</p>
        </div>
        <button
          onClick={() => handleOpenModal()}
          className="bg-orange-600 hover:bg-orange-700 text-white px-6 py-3 rounded-lg font-medium transition-colors flex items-center justify-center"
        >
          <Plus className="w-5 h-5 mr-2" />
          Novo Funcionário
        </button>
      </div>

      {/* Search */}
      <div className="bg-white rounded-xl shadow-sm border border-orange-100 p-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Buscar por nome, CPF, cargo ou departamento..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
          />
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl shadow-sm border border-orange-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-orange-50 border-b border-orange-100">
              <tr>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                  Funcionário
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                  CPF
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                  Cargo
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                  Departamento
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                  Admissão
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                  PCD
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                  Ações
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filteredEmployees.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-6 py-12 text-center">
                    <Users className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                    <p className="text-gray-500">Nenhum funcionário encontrado</p>
                  </td>
                </tr>
              ) : (
                filteredEmployees.map(employee => (
                  <tr key={employee.id} className="hover:bg-orange-50/50 transition-colors">
                    <td className="px-6 py-4">
                      <div>
                        <p className="font-medium text-gray-800">{employee.nomeCompleto}</p>
                        <p className="text-sm text-gray-500">{employee.email}</p>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-600">{employee.cpf}</td>
                    <td className="px-6 py-4 text-sm text-gray-600">{employee.cargo}</td>
                    <td className="px-6 py-4 text-sm text-gray-600">{employee.departamento}</td>
                    <td className="px-6 py-4 text-sm text-gray-600">{formatDate(employee.dataAdmissao)}</td>
                    <td className="px-6 py-4">
                      {employee.isPCD ? (
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-orange-100 text-orange-800">
                          <Check className="w-3 h-3 mr-1" />
                          Sim
                        </span>
                      ) : (
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-600">
                          Não
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => handleOpenModal(employee)}
                          className="p-2 text-gray-400 hover:text-orange-600 hover:bg-orange-50 rounded-lg transition-colors"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDelete(employee.id)}
                          className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  const renderNotifications = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">Alertas e Notificações</h2>
          <p className="text-gray-500">Acompanhe aniversários e férias dos funcionários</p>
        </div>
        {unreadNotifications.length > 0 && (
          <button
            onClick={handleMarkAllAsRead}
            className="text-orange-600 hover:text-orange-700 text-sm font-medium"
          >
            Marcar todos como lidos
          </button>
        )}
      </div>

      <div className="grid gap-4">
        {notifications.length === 0 ? (
          <div className="bg-white rounded-xl shadow-sm border border-orange-100 p-12 text-center">
            <Bell className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-800 mb-2">Nenhuma notificação</h3>
            <p className="text-gray-500">As notificações aparecerão aqui quando houver aniversários ou férias próximos</p>
          </div>
        ) : (
          notifications.map(notification => (
            <div
              key={notification.id}
              className={`bg-white rounded-xl shadow-sm border-l-4 p-6 ${
                notification.read 
                  ? 'border-gray-200 opacity-60' 
                  : notification.type === 'aniversario'
                    ? 'border-orange-500'
                    : 'border-blue-500'
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start space-x-4">
                  <div className={`p-3 rounded-full ${
                    notification.type === 'aniversario' 
                      ? 'bg-orange-100' 
                      : 'bg-blue-100'
                  }`}>
                    {notification.type === 'aniversario' ? (
                      <Calendar className="w-6 h-6 text-orange-600" />
                    ) : (
                      <Clock className="w-6 h-6 text-blue-600" />
                    )}
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-800">{notification.employeeName}</h3>
                    <p className="text-gray-600 mt-1">{notification.message}</p>
                    <div className="flex items-center mt-2 space-x-4">
                      <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${
                        notification.daysUntil <= 7
                          ? 'bg-red-100 text-red-800'
                          : notification.daysUntil <= 15
                            ? 'bg-orange-100 text-orange-800'
                            : 'bg-green-100 text-green-800'
                      }`}>
                        <AlertCircle className="w-3 h-3 mr-1" />
                        {notification.daysUntil === 0 
                          ? 'Hoje' 
                          : notification.daysUntil === 1 
                            ? 'Amanhã' 
                            : `Em ${notification.daysUntil} dias`
                        }
                      </span>
                      <span className="text-sm text-gray-500 flex items-center">
                        <Mail className="w-4 h-4 mr-1" />
                        Notificação por email enviada
                      </span>
                    </div>
                  </div>
                </div>
                {!notification.read && (
                  <button
                    onClick={() => handleMarkAsRead(notification.id)}
                    className="p-2 text-gray-400 hover:text-green-600 hover:bg-green-50 rounded-lg transition-colors"
                  >
                    <Check className="w-5 h-5" />
                  </button>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );

  const renderSettings = () => (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-800">Configurações</h2>
        <p className="text-gray-500">Ajuste as preferências do sistema</p>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-orange-100 p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Sobre o Sistema</h3>
        <div className="space-y-3 text-gray-600">
          <p><strong>Sistema:</strong> DBN RH - Gestão de Funcionários</p>
          <p><strong>Versão:</strong> 1.0.0</p>
          <p><strong>Alertas:</strong> Notificações de aniversário e férias com 45 dias de antecedência</p>
          <p><strong>Tema:</strong> Laranja e Branco</p>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-orange-100 p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Dados do Sistema</h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div>
              <p className="font-medium text-gray-800">Total de Funcionários</p>
              <p className="text-sm text-gray-500">Cadastrados no sistema</p>
            </div>
            <p className="text-2xl font-bold text-orange-600">{employees.length}</p>
          </div>
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div>
              <p className="font-medium text-gray-800">Notificações Pendentes</p>
              <p className="text-sm text-gray-500">Alertas não lidos</p>
            </div>
            <p className="text-2xl font-bold text-orange-600">{unreadNotifications.length}</p>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Sidebar */}
      <aside className={`fixed top-0 left-0 z-40 h-screen transition-transform ${
        sidebarOpen ? 'translate-x-0' : '-translate-x-full'
      } bg-gradient-to-b from-orange-600 to-orange-700 text-white w-64`}>
        <div className="h-full px-4 py-6 overflow-y-auto">
          {/* Logo */}
          <div className="mb-8 px-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center">
                <span className="text-orange-600 font-bold text-lg">DBN</span>
              </div>
              <div>
                <h1 className="text-xl font-bold">DBN RH</h1>
                <p className="text-xs text-orange-200">Gestão de Funcionários</p>
              </div>
            </div>
          </div>

          {/* Navigation */}
          <nav className="space-y-2">
            <button
              onClick={() => setCurrentView('dashboard')}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
                currentView === 'dashboard' 
                  ? 'bg-white/20 text-white' 
                  : 'text-orange-100 hover:bg-white/10'
              }`}
            >
              <Home className="w-5 h-5" />
              <span>Dashboard</span>
            </button>
            <button
              onClick={() => setCurrentView('employees')}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
                currentView === 'employees' 
                  ? 'bg-white/20 text-white' 
                  : 'text-orange-100 hover:bg-white/10'
              }`}
            >
              <Users className="w-5 h-5" />
              <span>Funcionários</span>
            </button>
            <button
              onClick={() => setCurrentView('notifications')}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
                currentView === 'notifications' 
                  ? 'bg-white/20 text-white' 
                  : 'text-orange-100 hover:bg-white/10'
              }`}
            >
              <Bell className="w-5 h-5" />
              <span>Alertas</span>
              {unreadNotifications.length > 0 && (
                <span className="ml-auto bg-white text-orange-600 text-xs font-bold px-2 py-0.5 rounded-full">
                  {unreadNotifications.length}
                </span>
              )}
            </button>
            <button
              onClick={() => setCurrentView('settings')}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
                currentView === 'settings' 
                  ? 'bg-white/20 text-white' 
                  : 'text-orange-100 hover:bg-white/10'
              }`}
            >
              <Settings className="w-5 h-5" />
              <span>Configurações</span>
            </button>
          </nav>

          {/* Footer */}
          <div className="absolute bottom-6 left-4 right-4">
            <div className="bg-white/10 rounded-lg p-4">
              <p className="text-xs text-orange-200">© 2026 DBN RH</p>
              <p className="text-xs text-orange-200 mt-1">Todos os direitos reservados</p>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <div className={`transition-all duration-300 ${sidebarOpen ? 'ml-64' : 'ml-0'}`}>
        {/* Top Bar */}
        <header className="bg-white border-b border-gray-200 sticky top-0 z-30">
          <div className="flex items-center justify-between px-6 py-4">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <Menu className="w-6 h-6 text-gray-600" />
            </button>
            
            <div className="flex items-center space-x-4">
              {/* Notifications Bell */}
              <div className="relative">
                <button
                  onClick={() => setShowNotifications(!showNotifications)}
                  className="p-2 hover:bg-gray-100 rounded-lg transition-colors relative"
                >
                  <Bell className="w-6 h-6 text-gray-600" />
                  {unreadNotifications.length > 0 && (
                    <span className="absolute top-1 right-1 w-4 h-4 bg-red-500 text-white text-xs font-bold rounded-full flex items-center justify-center">
                      {unreadNotifications.length}
                    </span>
                  )}
                </button>

                {/* Notifications Dropdown */}
                {showNotifications && (
                  <div className="absolute right-0 mt-2 w-80 bg-white rounded-xl shadow-lg border border-gray-200 py-2">
                    <div className="px-4 py-2 border-b border-gray-100">
                      <h3 className="font-semibold text-gray-800">Notificações</h3>
                    </div>
                    <div className="max-h-64 overflow-y-auto">
                      {unreadNotifications.length === 0 ? (
                        <p className="px-4 py-8 text-center text-gray-500 text-sm">
                          Nenhuma notificação pendente
                        </p>
                      ) : (
                        unreadNotifications.slice(0, 5).map(notification => (
                          <div
                            key={notification.id}
                            className="px-4 py-3 hover:bg-gray-50 cursor-pointer"
                            onClick={() => handleMarkAsRead(notification.id)}
                          >
                            <p className="text-sm text-gray-800 font-medium">{notification.message}</p>
                            <p className="text-xs text-gray-500 mt-1">
                              {notification.daysUntil === 0 
                                ? 'Hoje' 
                                : notification.daysUntil === 1 
                                  ? 'Amanhã' 
                                  : `Em ${notification.daysUntil} dias`
                              }
                            </p>
                          </div>
                        ))
                      )}
                    </div>
                    <div className="px-4 py-2 border-t border-gray-100">
                      <button
                        onClick={() => {
                          setCurrentView('notifications');
                          setShowNotifications(false);
                        }}
                        className="text-sm text-orange-600 hover:text-orange-700 font-medium"
                      >
                        Ver todas
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* User Profile */}
              <div className="flex items-center space-x-3 pl-4 border-l border-gray-200">
                <div className="w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center">
                  <span className="text-orange-600 font-semibold">AD</span>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-800">Administrador</p>
                  <p className="text-xs text-gray-500">RH DBN</p>
                </div>
              </div>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="p-6">
          {currentView === 'dashboard' && renderDashboard()}
          {currentView === 'employees' && renderEmployees()}
          {currentView === 'notifications' && renderNotifications()}
          {currentView === 'settings' && renderSettings()}
        </main>
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" onClick={handleCloseModal}>
          <div 
            className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
              {/* Modal Header */}
              <div className="bg-gradient-to-r from-orange-500 to-orange-600 px-6 py-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold text-white">
                    {editingEmployee ? 'Editar Funcionário' : 'Novo Funcionário'}
                  </h3>
                  <button
                    onClick={handleCloseModal}
                    className="text-white hover:bg-white/20 rounded-lg p-2 transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>

              {/* Modal Body */}
              <form onSubmit={handleSubmit} className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Nome Completo */}
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Nome Completo *
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.nomeCompleto}
                      onChange={(e) => setFormData({ ...formData, nomeCompleto: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                      placeholder="Ex: João da Silva"
                    />
                  </div>

                  {/* CPF */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      CPF *
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.cpf}
                      onChange={(e) => setFormData({ ...formData, cpf: formatCPF(e.target.value) })}
                      className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                      placeholder="000.000.000-00"
                      maxLength={14}
                    />
                  </div>

                  {/* Email */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Email *
                    </label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                      placeholder="email@dbn.com.br"
                    />
                  </div>

                  {/* Telefone */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Telefone
                    </label>
                    <input
                      type="tel"
                      value={formData.telefone}
                      onChange={(e) => setFormData({ ...formData, telefone: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                      placeholder="(00) 00000-0000"
                    />
                  </div>

                  {/* Data de Nascimento */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Data de Nascimento *
                    </label>
                    <input
                      type="date"
                      required
                      value={formData.dataNascimento}
                      onChange={(e) => setFormData({ ...formData, dataNascimento: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                    />
                  </div>

                  {/* Data de Admissão */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Data de Admissão *
                    </label>
                    <input
                      type="date"
                      required
                      value={formData.dataAdmissao}
                      onChange={(e) => setFormData({ ...formData, dataAdmissao: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                    />
                  </div>

                  {/* Cargo */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Cargo *
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.cargo}
                      onChange={(e) => setFormData({ ...formData, cargo: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                      placeholder="Ex: Analista de RH"
                    />
                  </div>

                  {/* Departamento */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Departamento *
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.departamento}
                      onChange={(e) => setFormData({ ...formData, departamento: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                      placeholder="Ex: Recursos Humanos"
                    />
                  </div>

                  {/* PCD Flag */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      É PCD?
                    </label>
                    <div className="flex items-center">
                      <button
                        type="button"
                        onClick={() => setFormData({ ...formData, isPCD: !formData.isPCD })}
                        className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                          formData.isPCD ? 'bg-orange-600' : 'bg-gray-200'
                        }`}
                      >
                        <span
                          className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                            formData.isPCD ? 'translate-x-6' : 'translate-x-1'
                          }`}
                        />
                      </button>
                      <span className="ml-3 text-sm text-gray-600">
                        {formData.isPCD ? 'Sim' : 'Não'}
                      </span>
                    </div>
                  </div>

                  {/* Data Férias Inicio */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Início das Férias
                    </label>
                    <input
                      type="date"
                      value={formData.dataFeriasInicio}
                      onChange={(e) => setFormData({ ...formData, dataFeriasInicio: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                    />
                  </div>

                  {/* Data Férias Fim */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Fim das Férias
                    </label>
                    <input
                      type="date"
                      value={formData.dataFeriasFim}
                      onChange={(e) => setFormData({ ...formData, dataFeriasFim: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                    />
                  </div>

                  {/* Status */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Status
                    </label>
                    <div className="flex items-center">
                      <button
                        type="button"
                        onClick={() => setFormData({ ...formData, ativo: !formData.ativo })}
                        className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                          formData.ativo ? 'bg-green-600' : 'bg-gray-200'
                        }`}
                      >
                        <span
                          className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                            formData.ativo ? 'translate-x-6' : 'translate-x-1'
                          }`}
                        />
                      </button>
                      <span className="ml-3 text-sm text-gray-600">
                        {formData.ativo ? 'Ativo' : 'Inativo'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Modal Footer */}
                <div className="mt-8 flex justify-end space-x-3">
                  <button
                    type="button"
                    onClick={handleCloseModal}
                    className="px-6 py-3 border border-gray-200 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-medium"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-3 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors font-medium"
                  >
                    {editingEmployee ? 'Salvar Alterações' : 'Cadastrar'}
                  </button>
                </div>
              </form>
          </div>
        </div>
      )}
    </div>
  );
}
