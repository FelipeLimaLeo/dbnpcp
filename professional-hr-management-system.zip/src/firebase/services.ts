import { 
  collection, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  doc, 
  getDocs, 
  getDoc,
  query,
  where,
  onSnapshot,
  DocumentData
} from 'firebase/firestore';
import { db } from './config';

// Types
export interface Employee {
  id?: string;
  nomeCompleto: string;
  cpf: string;
  dataNascimento: string;
  dataAdmissao: string;
  isPCD: boolean;
  email: string;
  telefone: string;
  cargo: string;
  departamento: string;
  dataFeriasInicio: string;
  dataFeriasFim: string;
  ativo: boolean;
  createdAt?: Date;
  updatedAt?: Date;
}

export interface Notification {
  id?: string;
  type: 'aniversario' | 'ferias' | 'geral';
  message: string;
  employeeName: string;
  employeeId: string;
  date: string;
  daysUntil: number;
  read: boolean;
  createdAt?: Date;
}

// Coleções do Firestore
const EMPLOYEES_COLLECTION = 'employees';
const NOTIFICATIONS_COLLECTION = 'notifications';

// ==================== FUNCIONÁRIOS ====================

// Criar funcionário
export const createEmployee = async (employee: Employee): Promise<string> => {
  try {
    const docRef = await addDoc(collection(db, EMPLOYEES_COLLECTION), {
      ...employee,
      createdAt: new Date(),
      updatedAt: new Date()
    });
    return docRef.id;
  } catch (error) {
    console.error('Erro ao criar funcionário:', error);
    throw error;
  }
};

// Atualizar funcionário
export const updateEmployee = async (id: string, employee: Partial<Employee>): Promise<void> => {
  try {
    const employeeRef = doc(db, EMPLOYEES_COLLECTION, id);
    await updateDoc(employeeRef, {
      ...employee,
      updatedAt: new Date()
    });
  } catch (error) {
    console.error('Erro ao atualizar funcionário:', error);
    throw error;
  }
};

// Excluir funcionário
export const deleteEmployee = async (id: string): Promise<void> => {
  try {
    await deleteDoc(doc(db, EMPLOYEES_COLLECTION, id));
  } catch (error) {
    console.error('Erro ao excluir funcionário:', error);
    throw error;
  }
};

// Buscar todos os funcionários
export const getAllEmployees = async (): Promise<Employee[]> => {
  try {
    const querySnapshot = await getDocs(collection(db, EMPLOYEES_COLLECTION));
    const employees: Employee[] = [];
    
    querySnapshot.forEach((doc) => {
      employees.push({
        id: doc.id,
        ...doc.data()
      } as Employee);
    });
    
    return employees;
  } catch (error) {
    console.error('Erro ao buscar funcionários:', error);
    throw error;
  }
};

// Buscar funcionário por ID
export const getEmployeeById = async (id: string): Promise<Employee | null> => {
  try {
    const docRef = doc(db, EMPLOYEES_COLLECTION, id);
    const docSnap = await getDoc(docRef);
    
    if (docSnap.exists()) {
      return {
        id: docSnap.id,
        ...docSnap.data()
      } as Employee;
    }
    
    return null;
  } catch (error) {
    console.error('Erro ao buscar funcionário:', error);
    throw error;
  }
};

// Buscar funcionários ativos
export const getActiveEmployees = async (): Promise<Employee[]> => {
  try {
    const q = query(collection(db, EMPLOYEES_COLLECTION), where('ativo', '==', true));
    const querySnapshot = await getDocs(q);
    const employees: Employee[] = [];
    
    querySnapshot.forEach((doc) => {
      employees.push({
        id: doc.id,
        ...doc.data()
      } as Employee);
    });
    
    return employees;
  } catch (error) {
    console.error('Erro ao buscar funcionários ativos:', error);
    throw error;
  }
};

// Ouvir mudanças em tempo real
export const subscribeToEmployees = (callback: (employees: Employee[]) => void): (() => void) => {
  const q = query(collection(db, EMPLOYEES_COLLECTION));
  
  const unsubscribe = onSnapshot(q, (querySnapshot) => {
    const employees: Employee[] = [];
    
    querySnapshot.forEach((doc) => {
      employees.push({
        id: doc.id,
        ...doc.data()
      } as Employee);
    });
    
    callback(employees);
  });
  
  return unsubscribe;
};

// ==================== NOTIFICAÇÕES ====================

// Criar notificação
export const createNotification = async (notification: Notification): Promise<string> => {
  try {
    const docRef = await addDoc(collection(db, NOTIFICATIONS_COLLECTION), {
      ...notification,
      createdAt: new Date()
    });
    return docRef.id;
  } catch (error) {
    console.error('Erro ao criar notificação:', error);
    throw error;
  }
};

// Atualizar notificação
export const updateNotification = async (id: string, notification: Partial<Notification>): Promise<void> => {
  try {
    const notificationRef = doc(db, NOTIFICATIONS_COLLECTION, id);
    await updateDoc(notificationRef, notification);
  } catch (error) {
    console.error('Erro ao atualizar notificação:', error);
    throw error;
  }
};

// Excluir notificação
export const deleteNotification = async (id: string): Promise<void> => {
  try {
    await deleteDoc(doc(db, NOTIFICATIONS_COLLECTION, id));
  } catch (error) {
    console.error('Erro ao excluir notificação:', error);
    throw error;
  }
};

// Buscar todas as notificações
export const getAllNotifications = async (): Promise<Notification[]> => {
  try {
    const querySnapshot = await getDocs(collection(db, NOTIFICATIONS_COLLECTION));
    const notifications: Notification[] = [];
    
    querySnapshot.forEach((doc) => {
      notifications.push({
        id: doc.id,
        ...doc.data()
      } as Notification);
    });
    
    return notifications;
  } catch (error) {
    console.error('Erro ao buscar notificações:', error);
    throw error;
  }
};

// Buscar notificações não lidas
export const getUnreadNotifications = async (): Promise<Notification[]> => {
  try {
    const q = query(collection(db, NOTIFICATIONS_COLLECTION), where('read', '==', false));
    const querySnapshot = await getDocs(q);
    const notifications: Notification[] = [];
    
    querySnapshot.forEach((doc) => {
      notifications.push({
        id: doc.id,
        ...doc.data()
      } as Notification);
    });
    
    return notifications;
  } catch (error) {
    console.error('Erro ao buscar notificações não lidas:', error);
    throw error;
  }
};

// Marcar notificação como lida
export const markNotificationAsRead = async (id: string): Promise<void> => {
  try {
    await updateNotification(id, { read: true });
  } catch (error) {
    console.error('Erro ao marcar notificação como lida:', error);
    throw error;
  }
};

// Marcar todas as notificações como lidas
export const markAllNotificationsAsRead = async (): Promise<void> => {
  try {
    const unreadNotifications = await getUnreadNotifications();
    
    const updatePromises = unreadNotifications.map(notification => {
      if (notification.id) {
        return updateNotification(notification.id!, { read: true });
      }
      return Promise.resolve();
    });
    
    await Promise.all(updatePromises);
  } catch (error) {
    console.error('Erro ao marcar todas notificações como lidas:', error);
    throw error;
  }
};

// Ouvir notificações em tempo real
export const subscribeToNotifications = (callback: (notifications: Notification[]) => void): (() => void) => {
  const unsubscribe = onSnapshot(collection(db, NOTIFICATIONS_COLLECTION), (querySnapshot) => {
    const notifications: Notification[] = [];
    
    querySnapshot.forEach((doc) => {
      notifications.push({
        id: doc.id,
        ...doc.data()
      } as Notification);
    });
    
    callback(notifications);
  });
  
  return unsubscribe;
};

// Limpar notificações antigas (mais de 1 ano)
export const cleanupOldNotifications = async (): Promise<void> => {
  try {
    const oneYearAgo = new Date();
    oneYearAgo.setFullYear(oneYearAgo.getFullYear() - 1);
    
    const querySnapshot = await getDocs(collection(db, NOTIFICATIONS_COLLECTION));
    const deletePromises: Promise<void>[] = [];
    
    querySnapshot.forEach((doc) => {
      const data = doc.data() as DocumentData;
      const createdAt = data.createdAt?.toDate();
      
      if (createdAt && createdAt < oneYearAgo) {
        deletePromises.push(deleteDoc(doc.ref));
      }
    });
    
    await Promise.all(deletePromises);
  } catch (error) {
    console.error('Erro ao limpar notificações antigas:', error);
    throw error;
  }
};
